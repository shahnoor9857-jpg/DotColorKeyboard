package com.example.dotcolorkeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;

public class DotKeyboardService extends InputMethodService {
    private final int[] colors = {
        Color.rgb(231,184,52), Color.rgb(43,83,137), Color.rgb(29,30,35),
        Color.rgb(239,236,232), Color.rgb(194,49,52)
    };
    private int colorIndex = 0;

    @Override public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(5), dp(8), dp(5), dp(6));
        root.setBackgroundColor(Color.BLACK);

        // Compact preview / suggestion bar
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        Button symbol = key("☻", colors[1], Color.WHITE, 0);
        Button suggestion = key("Tap keys to type", Color.rgb(32,39,41), Color.WHITE, 0);
        top.addView(symbol, new LinearLayout.LayoutParams(dp(48), dp(44)));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(44), 1);
        sp.leftMargin = dp(5);
        top.addView(suggestion, sp);
        root.addView(top);

        String[][] rows = {
            {"q","w","e","r","t","y","u","i","o","p"},
            {"a","s","d","f","g","h","j","k","l"},
            {"⇧","z","x","c","v","b","n","m","⌫"},
            {"?123","☺",",","space",".","↵"}
        };
        int[][] rowColors = {
            {0,1,2,3,4,1,3,4,0,2},
            {3,4,1,2,0,3,4,1,2},
            {0,2,0,3,4,1,2,0,3},
            {4,1,3,2,3,4}
        };
        for (int r = 0; r < rows.length; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(r == 3 ? 54 : 58));
            rp.topMargin = dp(5);
            root.addView(row, rp);
            for (int c = 0; c < rows[r].length; c++) {
                String label = rows[r][c];
                int ci = rowColors[r][c];
                int fg = (ci == 1 || ci == 2 || ci == 4) ? Color.WHITE : Color.rgb(24,24,24);
                Button b = key(label, colors[ci], fg, 1);
                LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(0, -1, weightFor(label));
                kp.leftMargin = dp(2);
                kp.rightMargin = dp(2);
                row.addView(b, kp);
                b.setOnClickListener(v -> handleKey(label));
            }
        }
        return root;
    }

    private float weightFor(String key) {
        if (key.equals("space")) return 4.0f;
        if (key.equals("⇧") || key.equals("⌫") || key.equals("?123") || key.equals("↵")) return 1.35f;
        if (key.equals("☺") || key.equals(",") || key.equals(".")) return 0.8f;
        return 1.0f;
    }

    private Button key(String label, int bg, int fg, int ignored) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, label.length() > 2 ? 13 : 20);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, 0, 0, 0);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    private void handleKey(String key) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        switch (key) {
            case "⌫":
                ic.deleteSurroundingText(1, 0);
                break;
            case "↵":
                ic.commitText("\n", 1);
                break;
            case "space":
                ic.commitText(" ", 1);
                break;
            case "⇧":
                // Shift is a visual starter; uppercase the next character can be added later.
                break;
            case "?123":
                // Number/symbol mode can be added as a second layout.
                break;
            case "☺":
                ic.commitText("☺", 1);
                break;
            default:
                ic.commitText(key, 1);
        }
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
