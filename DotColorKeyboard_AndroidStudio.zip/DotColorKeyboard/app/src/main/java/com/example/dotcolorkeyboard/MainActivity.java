package com.example.dotcolorkeyboard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 26, 22, 22);
        root.setBackgroundColor(Color.rgb(12,12,13));

        TextView title = new TextView(this);
        title.setText("Dot Color Keyboard");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 10, 0, 18);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText("Enable the keyboard, then select it as your default input method. Try typing in the box below.");
        desc.setTextColor(Color.LTGRAY);
        desc.setTextSize(15);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(4, 0, 4, 20);
        root.addView(desc);

        EditText demo = new EditText(this);
        demo.setSingleLine(false);
        demo.setMinLines(3);
        demo.setHint("Tap here to try the keyboard…");
        demo.setTextColor(Color.WHITE);
        demo.setHintTextColor(Color.GRAY);
        demo.setPadding(14, 14, 14, 14);
        demo.setBackgroundColor(Color.rgb(32,36,38));
        root.addView(demo, new LinearLayout.LayoutParams(-1, -2));

        Button enable = new Button(this);
        enable.setText("1. Enable keyboard in Settings");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable, marginParams());

        Button choose = new Button(this);
        choose.setText("2. Choose Dot Color Keyboard");
        choose.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        root.addView(choose, marginParams());

        setContentView(root);
    }
    private LinearLayout.LayoutParams marginParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 12;
        return p;
    }
}
