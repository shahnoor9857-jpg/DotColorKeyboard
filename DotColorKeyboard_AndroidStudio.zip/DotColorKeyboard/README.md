# Dot Color Keyboard (Android Studio starter)

A starter Android custom keyboard (IME) inspired by the reference image: black background, rounded keys, and a yellow/blue/red/white/charcoal palette.

## Open and run
1. Extract this ZIP.
2. Open the `DotColorKeyboard` folder in Android Studio.
3. Let Gradle sync finish.
4. Run on an Android phone or emulator.
5. Open the app and tap **Enable keyboard in Settings**.
6. Enable **Dot Color Keyboard**, return to the app, then tap **Choose Dot Color Keyboard**.
7. Open any app and type.

## Included
- Android InputMethodService keyboard
- Colored QWERTY-style layout
- Letter, space, backspace, enter, and emoji key handling
- Demo screen with setup buttons

## Notes
This is a working starter, not a pixel-perfect clone. The reference uses a distinctive dotted glyph style; this starter uses bold monospaced letters so it works without custom fonts. Number/symbol mode and shift/caps behavior are placeholders to extend next. Android Studio/Gradle may download the Android Gradle Plugin and SDK components during first sync.
